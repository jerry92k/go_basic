**Deprecated:** Use https://pkg.go.dev/golang.org/x/tools/go/analysis/passes/fieldalignment instead.

Install:

    go get github.com/mdempsky/maligned

Usage:

    maligned cmd/compile/internal/gc cmd/link/internal/ld
