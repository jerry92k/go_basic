package code

func init() {
}

var theVar = true
