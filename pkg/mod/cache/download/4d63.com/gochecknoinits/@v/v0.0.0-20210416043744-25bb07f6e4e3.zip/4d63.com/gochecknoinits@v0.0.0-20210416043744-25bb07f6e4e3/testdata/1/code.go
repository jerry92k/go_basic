package code

const constant = 0

func function(arg string) bool {
	yourVar := true
	return yourVar
}
