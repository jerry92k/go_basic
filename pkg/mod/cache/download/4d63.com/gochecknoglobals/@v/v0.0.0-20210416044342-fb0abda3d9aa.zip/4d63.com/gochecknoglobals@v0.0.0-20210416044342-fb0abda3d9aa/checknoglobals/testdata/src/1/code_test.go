package code_test

const constant = 0
